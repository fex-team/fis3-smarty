
fis.require('smarty')(fis);
fis.set('namespace', 'home');

// default media is `dev`，
fis.media('dev').match('*', {
    useHash: false,
    optimizer: null
});

