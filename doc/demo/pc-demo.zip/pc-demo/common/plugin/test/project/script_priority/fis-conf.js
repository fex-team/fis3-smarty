fis.config.merge({
	namespace: "priority"
});