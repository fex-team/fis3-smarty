<?php

if (!defined('PLUGIN_DIR')) define('PLUGIN_DIR', dirname(dirname(__FILE__)) . '/');