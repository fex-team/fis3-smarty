

fis.require('smarty')(fis);
fis.set('namespace', 'common');

// default media is `dev`，
fis.media('dev').match('*', {
    useHash: false,
    optimizer: null
});

