exports.run = function(){
	console.log("test");
    $('html').toggleClass('expanded');
};