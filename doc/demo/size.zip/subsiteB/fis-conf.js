require('fis3-smarty')(fis);
fis.set('namespace', 'B');
